/*TABLE CREATION */

CREATE TABLE Token (
  name varchar(30) NOT NULL,
  PRIMARY KEY (name)
);

CREATE TABLE Location(
  name varchar(30) NOT NULL,
  PRIMARY KEY (name)
);

CREATE TABLE Property (
  name varchar(30) NOT NULL,
  cost int NOT NULL,
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Location(name)
);

CREATE TABLE Blues(
  name varchar(30),
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Property(name)
);

CREATE TABLE Yellows(
  name varchar(30),
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Property(name)
);
CREATE TABLE Oranges(
  name varchar(30),
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Property(name)
);

CREATE TABLE Greens(
  name varchar(30),
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Property(name)
);

CREATE TABLE Bonus(
  name varchar(30) NOT NULL,
  description varchar (255) NOT NULL,
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Location(name)
);

CREATE TABLE BonusAction(
  name varchar(30) NOT NULL,
  action INT NOT NULL,
  PRIMARY KEY (name),
  FOREIGN KEY (name) REFERENCES Bonus(name)
);

CREATE TABLE Audit_Trail(
  diceroll int AUTO_INCREMENT,
  round int NOT NULL,
  playerid int NOT NULL,
  location varchar(30) NOT NULL,
  bonus varchar(30),
  balance int NOT NULL,
  PRIMARY KEY (diceroll),
  FOREIGN KEY (location) REFERENCES Location(name)
);

CREATE TABLE Player (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(30) NOT NULL,
  token varchar(30) NOT NULL,
  balance int NOT NULL,
  location varchar(30) NOT NULL,
  PRIMARY KEY (id),
  FOREIGN KEY (token) REFERENCES Token(name),
  FOREIGN KEY (location) REFERENCES Location(name)
);

CREATE TABLE PropertyOwner(
  ownerid int NOT NULL,
  propertyname varchar(30) NOT NULL,
  PRIMARY KEY (ownerid,propertyname),
  FOREIGN KEY (ownerid) REFERENCES Player(id),
  FOREIGN KEY (propertyname) REFERENCES Property(name)
);

CREATE TABLE BonusPlayer (
  ID INT  AUTO_INCREMENT,
  round INT NOT NULL,
  playerid int NOT NULL,
  bonus varchar(30),
  PRIMARY KEY (ID,round),
  FOREIGN KEY (playerid) REFERENCES Player(id),
  FOREIGN KEY (bonus) REFERENCES Bonus(name)
);

CREATE TABLE Audit_TrailPlayer(
  ID int AUTO_INCREMENT,
  round int NOT NULL,
  playerid int NOT NULL,
  PRIMARY KEY (ID,playerid),
  FOREIGN KEY (playerid) REFERENCES Player(id),
  FOREIGN KEY (ID) REFERENCES Audit_Trail(diceroll)
);
