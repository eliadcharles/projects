/*Monopolee Commands*/

/*gameView*/
CREATE VIEW gameView AS
SELECT Player.name,
Player.location,
Player.Balance,
MAX(Audit_TrailPlayer.round) Round,
GROUP_CONCAT(DISTINCT PropertyOwner.propertyname SEPARATOR ',') Properties
FROM PropertyOwner
LEFT JOIN (Player LEFT JOIN Audit_TrailPlayer ON Audit_TrailPlayer.playerid = Player.id)
ON Player.id = PropertyOwner.ownerid
GROUP BY Player.name, Player.location,Player.balance
ORDER BY Player.Balance DESC;

SELECT *
FROM gameView;

/*Jane rolls 3*/
INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(1,3,'GO', 350,'GO');

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 1;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 1;

UPDATE Player
INNER JOIN (Audit_Trail INNER JOIN BonusAction
   ON Audit_Trail.location=BonusAction.name)
ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location,
Player.balance = (Player.balance + BonusAction.action)
WHERE Player.id = 3;

SELECT *
FROM gameView;

/*Norman rolls 1*/
INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(1,4,'Chance 1',100,'Chance 1');

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 2;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 2;

/*Updates*/
UPDATE Player
INNER JOIN (Audit_Trail INNER JOIN BonusAction
  ON Audit_Trail.location=BonusAction.name)
ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location,
Player.balance = (Player.balance - (BonusAction.action*3))
WHERE Player.id = 4;

UPDATE Player
SET
Player.balance = (Player.balance + (SELECT BonusAction.action
FROM BonusAction
WHERE BonusAction.name = 'Chance 1'))
WHERE
Player.id IN (1,2,3);

SELECT *
FROM gameView;

/*Mary rolls 4*/
INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(1,1,'Jail',240,'Go To Jail');

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 3;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 3;

/*Updates*/
UPDATE Player
INNER JOIN Audit_Trail ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location
WHERE Player.id = 1;

SELECT *
FROM gameView;

/* Bill rolls 2*/

INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(1,2,'AMBS',150, NULL);

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 4;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 4;

INSERT INTO PropertyOwner (ownerid,propertyname)
SELECT playerid, location
FROM Audit_Trail
WHERE diceroll=4;


/*Updates*/
UPDATE Player
LEFT JOIN (Audit_Trail RIGHT JOIN Property
  ON Audit_Trail.location=Property.name)
ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location,
Player.balance = (Player.balance - Property.cost)
WHERE Player.id = 2;


SELECT *
FROM gameView;

/*ROUND 2*/
/*G5: Jane rolls a 5*/

INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(2,3,'Victoria',325, NULL);

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 5;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 5;


/*Updates*/
UPDATE Player
LEFT JOIN (Audit_Trail RIGHT JOIN Property
  ON Audit_Trail.location=Property.name)
ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location,
Player.balance = (Player.balance - Property.cost)
WHERE Player.id = 3 AND  Audit_Trail.diceroll = 5;

Update Player
INNER JOIN (PropertyOwner INNER JOIN Property
  ON PropertyOwner.propertyname = Property.name)
ON Player.id = PropertyOwner.ownerid
SET
Player.balance = (Player.balance + Property.cost)
WHERE Player.id = 2 AND Property.name = 'Victoria';

SELECT *
FROM gameView;


/*G6: Norman rolls a 4*/

INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(2,4,'Community Chest 1', 200,'Community Chest 1');

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 6;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 6;

/*Updates*/
UPDATE Player
INNER JOIN (Audit_Trail INNER JOIN BonusAction
  ON Audit_Trail.location=BonusAction.name)
ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location,
Player.balance = (Player.balance + BonusAction.action)
WHERE Player.id = 4 AND Audit_Trail.diceroll = 6;

SELECT *
FROM gameView;

/*G7: Mary rolls a 6, and then a 5 */

INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(2,1,'Jail',240, NULL),
(2,1,'Oak House',40, NULL);

INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 7;
INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll = 8;

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 7;
INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll = 8;

/*Update Mary*/
UPDATE Player
LEFT JOIN (Audit_Trail RIGHT JOIN Property
   ON Audit_Trail.location=Property.name)
ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location,
Player.balance = (Player.balance - (Property.cost*2))
WHERE Player.id = 1 AND  Audit_Trail.diceroll = 8;

/*Update Norman */
UPDATE Player
INNER JOIN (PropertyOwner INNER JOIN Property
  ON PropertyOwner.propertyname= Property.name)
ON Player.id = PropertyOwner.ownerid
SET Player.balance = (Player.balance + (Property.cost*2))
WHERE Player.id = 4 AND Property.name = 'Oak House';

SELECT *
FROM gameView;

/*G8: Bill rolls a 6, and then a 3*/
INSERT INTO Audit_Trail
(round,playerid,location,balance,bonus)
VALUES
(2,2,'Uni Place',425, 'GO'),
(2,2,'Community Chest 1',525, 'Community Chest 1');


INSERT INTO Audit_TrailPlayer (round,playerid)
SELECT round,playerid
FROM Audit_Trail
WHERE diceroll IN (9,10);

INSERT INTO BonusPlayer (playerid,round,bonus)
SELECT playerid, round, bonus
FROM Audit_Trail
WHERE diceroll IN (9,10);

UPDATE Player
INNER JOIN Audit_Trail ON Player.id = Audit_Trail.playerid
SET
Player.location = Audit_Trail.location
WHERE Player.id = 2 AND Audit_Trail.diceroll = 10;

UPDATE Player
SET
Player.balance = (Player.balance + (SELECT BonusAction.action
FROM BonusAction
WHERE BonusAction.name = 'GO') + (SELECT BonusAction.action
FROM BonusAction
WHERE BonusAction.name = 'Community Chest 1'))
WHERE
Player.id = 2;


SELECT *
FROM gameView;
