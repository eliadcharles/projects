/*INITIAL STATE: Populating TABLES*/

INSERT INTO Token
VALUES
('Battleship'),
('Dog'),
('Thimble'),
('Car'),
('Hat'),
('Boot');

INSERT INTO Location
VALUES
('Chance 1'),
('Chance 2'),
('Community Chest 1'),
('Community Chest 2'),
('Free Parking'),
('Go To Jail'),
('GO'),
('Oak House'),
('Owens Park'),
('AMBS'),
('Co-Op'),
('Kilburn'),
('Uni Place'),
('Victoria'),
('Picadilly'),
('Jail');

INSERT INTO Bonus
VALUES
('Chance 1','Pay each of the other players £50'),
('Chance 2', 'Move forward 3 spaces'),
('Community Chest 1','You have won a Beauty Context, win £100'),
('Community Chest 2','Your library books are overdue. Pay fine of £30'),
('Free Parking','No Action'),
('Go To Jail','Got to Jail, do not pass GO'),
('GO','Collect £200');

INSERT INTO BonusAction
VALUES
('Chance 1', 50),
('Community Chest 1', 100),
('Community Chest 2', 30),
('GO', 200);

INSERT INTO Property
VALUES
('Oak House',100),
('Owens Park', 30),
('AMBS',400),
('Co-Op', 30),
('Kilburn', 120),
('Uni Place', 100),
('Victoria', 75),
('Picadilly', 35);

INSERT INTO Player
(name, token, location, balance)
VALUES
('Mary', 'Battleship', 'Free Parking', 190),
('Bill', 'Dog', 'Owens Park', 500),
('Jane', 'Car', 'AMBS', 150),
('Norman', 'Thimble', 'Kilburn',  250);

INSERT INTO PropertyOwner
VALUES
(1,'Uni Place'),
(2,'Victoria'),
(3, 'Co-op'),
(4,'Oak House'),
(4,'Owens Park');


INSERT INTO Blues
VALUES
('AMBS'),
('Co-op');

INSERT INTO Oranges
VALUES
('Oak House'),
('Owens Park');

INSERT INTO Yellows
VALUES
('Kilburn'),
('Uni Place');

INSERT INTO Greens
VALUES
('Victoria'),
('Picadilly');
