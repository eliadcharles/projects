CREATE VIEW gameView AS
SELECT Player.name
,Player.location,
Player.Balance,
MAX(BonusPlayer.bonus) Last_Bonus,
MAX(Audit_TrailPlayer.round) Round,
GROUP_CONCAT(DISTINCT PropertyOwner.propertyname SEPARATOR ',') Properties
FROM PropertyOwner
LEFT JOIN (Player LEFT JOIN
  (Audit_TrailPlayer LEFT JOIN BonusPlayer
    ON BonusPlayer.playerid = Audit_TrailPlayer.playerid)
  ON Audit_TrailPlayer.playerid = Player.id)
ON Player.id = PropertyOwner.ownerid
GROUP BY Player.name, Player.location,Player.balance
ORDER BY Player.Balance DESC;

SELECT *
FROM gameView;
